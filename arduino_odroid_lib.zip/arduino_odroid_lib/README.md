# arduino_odroid_lib
Arduino Library for communication with SyboNav system
